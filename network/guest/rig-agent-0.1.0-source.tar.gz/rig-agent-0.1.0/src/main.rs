use anyhow::Result;
use rig_core::{
    client::{CompletionClient, ProviderClient},
    completion::Prompt,
    providers::openai,
    tool::Tool,
};
use serde::{Deserialize, Serialize};
use serde_json::json;

fn project_path(path: &str) -> std::io::Result<std::path::PathBuf> {
    let relative = std::path::Path::new(path);
    if relative.is_absolute() || relative.components().any(|part| matches!(part, std::path::Component::ParentDir)) {
        return Err(std::io::Error::new(std::io::ErrorKind::PermissionDenied, "path must stay inside the project"));
    }
    Ok(std::env::current_dir()?.join(relative))
}

#[derive(Deserialize)]
struct WriteArgs {
    path: String,
    content: String,
}

#[derive(Debug, thiserror::Error)]
#[error("write failed: {0}")]
struct WriteError(#[from] std::io::Error);

#[derive(Deserialize, Serialize)]
struct WriteFile;

impl Tool for WriteFile {
    const NAME: &'static str = "write_file";
    type Error = WriteError;
    type Args = WriteArgs;
    type Output = String;

    fn description(&self) -> String {
        "Write UTF-8 content to a file beneath the current project directory".into()
    }

    fn parameters(&self) -> serde_json::Value {
        json!({
            "type": "object",
            "properties": {
                "path": { "type": "string" },
                "content": { "type": "string" }
            },
            "required": ["path", "content"]
        })
    }

    async fn call(&self, args: Self::Args) -> Result<Self::Output, Self::Error> {
        let path = project_path(&args.path)?;
        if let Some(parent) = path.parent() {
            std::fs::create_dir_all(parent)?;
        }
        std::fs::write(path, args.content.as_bytes())?;
        Ok(format!("wrote {}", args.path))
    }
}

#[derive(Deserialize)]
struct PathArgs { path: String }

#[derive(Deserialize, Serialize)]
struct ReadFile;

impl Tool for ReadFile {
    const NAME: &'static str = "read_file";
    type Error = WriteError;
    type Args = PathArgs;
    type Output = String;
    fn description(&self) -> String { "Read a UTF-8 project file".into() }
    fn parameters(&self) -> serde_json::Value {
        json!({"type":"object","properties":{"path":{"type":"string"}},"required":["path"]})
    }
    async fn call(&self, args: Self::Args) -> Result<Self::Output, Self::Error> {
        Ok(std::fs::read_to_string(project_path(&args.path)?)?)
    }
}

#[derive(Deserialize, Serialize)]
struct ListDirectory;

impl Tool for ListDirectory {
    const NAME: &'static str = "list_directory";
    type Error = WriteError;
    type Args = PathArgs;
    type Output = String;
    fn description(&self) -> String { "List files in a project directory".into() }
    fn parameters(&self) -> serde_json::Value {
        json!({"type":"object","properties":{"path":{"type":"string"}},"required":["path"]})
    }
    async fn call(&self, args: Self::Args) -> Result<Self::Output, Self::Error> {
        let mut names = std::fs::read_dir(project_path(&args.path)?)?
            .filter_map(Result::ok)
            .map(|entry| entry.file_name().to_string_lossy().into_owned())
            .collect::<Vec<_>>();
        names.sort();
        Ok(names.join("\n"))
    }
}

#[derive(Deserialize)]
struct ShellArgs { command: String }

#[derive(Deserialize, Serialize)]
struct Shell;

impl Tool for Shell {
    const NAME: &'static str = "shell";
    type Error = WriteError;
    type Args = ShellArgs;
    type Output = String;
    fn description(&self) -> String { "Run a shell command in the project directory".into() }
    fn parameters(&self) -> serde_json::Value {
        json!({"type":"object","properties":{"command":{"type":"string"}},"required":["command"]})
    }
    async fn call(&self, args: Self::Args) -> Result<Self::Output, Self::Error> {
        let output = std::process::Command::new("/bin/sh").arg("-c").arg(args.command).output()?;
        Ok(format!("{}{}", String::from_utf8_lossy(&output.stdout), String::from_utf8_lossy(&output.stderr)))
    }
}

#[tokio::main(flavor = "current_thread")]
async fn main() -> Result<()> {
    let prompt = std::env::args().skip(1).collect::<Vec<_>>().join(" ");
    let client = openai::CompletionsClient::from_env()?;
    let agent = client
        .agent(std::env::var("OPENAI_MODEL").unwrap_or_else(|_| "webgpu".into()))
        .preamble("You are a concise coding agent operating in the current project. Inspect files and use tools to complete the request, then report the result.")
        .tool(ReadFile)
        .tool(ListDirectory)
        .tool(WriteFile)
        .tool(Shell)
        .default_max_turns(6)
        .build();
    println!("{}", agent.prompt(prompt).await?);
    Ok(())
}
